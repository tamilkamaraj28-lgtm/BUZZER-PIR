#include <LiquidCrystal.h>
LiquidCrystal lcd(3,4,5,6,7,8);
int in = 2;
int out = 11;
void setup(){
  pinMode(in,INPUT);
  pinMode(out,OUTPUT);
  lcd.begin(16,2);
}
void loop(){
  
  int sensorvalue = digitalRead(in);
  if(sensorvalue ==  HIGH)
  {
    tone(out,6000);
  lcd.setCursor(6,0);
  lcd.print("motion");
  lcd.setCursor(4,1);
  lcd.print("detection");
  delay(100);
  }
  else{
    noTone(out);
    lcd.setCursor(4,0);
  lcd.print("motion not");
  lcd.setCursor(4,1);
  lcd.print("detection");
  delay(100);
  }
}


